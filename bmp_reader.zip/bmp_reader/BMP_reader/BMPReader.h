#pragma once
#include <fstream>
#include <iostream>
#include <string>
#include <deque>

struct RGB {
	uint8_t r;
	uint8_t g;
	uint8_t b;
};

class BMPReader
{
	std::deque<std::deque<RGB>> rgbImage;
public:
	void openBMP(const std::string& fileName);
	void displayBMP() const;
	void closeBMP();
};

